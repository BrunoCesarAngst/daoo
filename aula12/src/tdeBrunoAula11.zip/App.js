import React, { useState, useEffect } from 'react';

import Header from './components/Header.js'
import Nav from './components/Nav.js'
import Section from './components/Section.js'
import Footer from './components/Footer.js'

function App() {
  const [page, setPage] = useState('Home Inicial')

  useEffect(() => {
    console.log('page')
  }, [page])

  return (
    <div>
      <Header />
      <Nav onSetPage={setPage} />
      <Section onPage={page} />
      <Footer />
    </div>
  );
}

export default App;
